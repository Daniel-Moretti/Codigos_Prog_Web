-- DropIndex
DROP INDEX "Ies_cnpj_key";
